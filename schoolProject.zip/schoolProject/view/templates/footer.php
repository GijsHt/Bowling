
<footer class="bg-dark fixed-bottom">
    <p class="text-white p-2 m-0 text-center">&copy; Berkan Kaya - 2020</p>
</footer>
